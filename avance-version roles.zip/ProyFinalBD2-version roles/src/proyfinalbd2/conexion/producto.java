
package proyfinalbd2.conexion;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class producto {
    private String nombre;
    private double precio;

    public producto() {
    }

    public producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    //mostrar productos en una tabla
    public static void mostrarProductosEnTabla(JTable tablaProductos) {
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"ID", "Nombre", "P.Unitario"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);

        // Consulta SQL
        String sql = "SELECT * FROM productos ORDER BY id_producto ASC";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[3];

        conexion c = new conexion(); // tu clase de conexión
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);

                modelo.addRow(datos);
            }

            // Asignar el modelo al JTable
            tablaProductos.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar clientes en la tabla: " + e.toString());
        }
    }
    
    //mostrar productos en una tabla para registrarlos en un pedido
    public static void obtenerTablaProductosParaPedidos(JTable tablaProductos) {
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"id_producto", "nombre", "precio"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);

        // Consulta SQL
        String sql = "SELECT * FROM productos ORDER BY id_producto ASC";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[3];

        conexion c = new conexion(); // tu clase de conexión
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);

                modelo.addRow(datos);
            }

            // Asignar el modelo al JTable
            tablaProductos.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar clientes en la tabla: " + e.toString());
        }
    }
    
    //insertar producto a la BD
    public void insertarProducto(){
        conexion con=new conexion();
        String sql="insert into productos(nombre,precio) values(?,?);";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setString(1, this.nombre);
            cs.setDouble(2, this.precio);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "Producto registrado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //modificar productos en la BD
    public void modificarProducto(int id){
        conexion con=new conexion();
        String sql="update productos set nombre=?, precio=? where id_producto=?;";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setString(1, this.nombre);
            cs.setDouble(2, this.precio);
            cs.setInt(3, id);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "producto modificado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //mostrar datos del producto seleccionado en la ventana modificar
    public void mostrarDatosProductoAModificar(String id,JTextField inputNombre,JTextField inputPrecio){
        conexion c=new conexion();
        String sql="";
        
        sql="select * from productos where id_producto="+id+";";
        
        String[] datos=new String[3];
        
        Statement st;
        
        try{
            st=c.establecerConexion().createStatement();
            
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                
                inputNombre.setText(datos[1]);
                inputPrecio.setText(datos[2]);
                
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //eliminar un producto de la BD
    public void eliminarProducto(int id){
        conexion con=new conexion();
        String sql="delete from productos where id_producto=?;";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setInt(1, id);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "producto eliminado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
}
