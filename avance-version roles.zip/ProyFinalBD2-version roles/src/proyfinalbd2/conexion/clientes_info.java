
package proyfinalbd2.conexion;

import com.mongodb.client.MongoCollection;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import static com.mongodb.client.model.Updates.set;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class clientes_info {
    
    //mostrar comentarios en tabla
    public static void mostrarComentariosEnTabla(JTable tablaComentarios){
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"ID cliente", "Nombre", "Comentario", "Fecha"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        String datos[] = new String[4];
        
        try {
            //se establace la conexion y se guarda la coleccion de clientes_info
            conexion_MongoDB conexion = new conexion_MongoDB();
            MongoCollection<Document> coleccion = conexion.crearConexion();
            for (Document doc : coleccion.find()) {
                int idCliente = doc.getInteger("id_cliente");
                List<Document> comentarios = doc.getList("comentarios", Document.class);

                if (comentarios != null && !comentarios.isEmpty()) {
                    for (Document comentario : comentarios) {
                        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");//formateamos la fecha para pasarla a String
                        String fechaFormateada = formato.format(comentario.getDate("fecha"));
                        datos[0] = Integer.toString(idCliente);
                        datos[1] = cliente.obtenerNombreCliente(idCliente);
                        datos[2] = comentario.getString("texto");
                        datos[3] = fechaFormateada;
                        modelo.addRow(datos);
                    }
                } 

            }
            // Asignar el modelo al JTable
            tablaComentarios.setModel(modelo);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar comentarios en la tabla: " + e.toString());
        }

    }
    
    //mostrar preferencias en tabla
    public static void mostrarPreferenciasEnTabla(JTable tablaPreferencias){
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"ID cliente", "Nombre", "Idioma", "Metodo de pago", "Notificaciones"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        String datos[] = new String[5];
        
        try {
            //se establace la conexion y se guarda la coleccion de clientes_info
            conexion_MongoDB conexion = new conexion_MongoDB();
            MongoCollection<Document> coleccion = conexion.crearConexion();
            
            for (Document doc : coleccion.find()) {
                int idCliente = doc.getInteger("id_cliente");
                Document preferencias = doc.get("preferencias", Document.class);

                if (preferencias != null) {
                    datos[0] = Integer.toString(idCliente);
                    datos[1] = cliente.obtenerNombreCliente(idCliente);
                    datos[2] = preferencias.getString("idioma");
                    datos[3] = preferencias.getString("metodo_pago");
                    if(preferencias.getBoolean("notificaciones")){
                        datos[4] = "Si";
                    }else datos[4] = "No";
                    
                    modelo.addRow(datos);
                } 
            }
            // Asignar el modelo al JTable
            tablaPreferencias.setModel(modelo);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar preferencias en la tabla: " + e.toString());
        }
    }
    
    public static void insertarComentario(int idCliente,String textoComentario, Date Fecha) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();

        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();

        Document nuevoComentario = new Document("texto", textoComentario)
                .append("fecha", Fecha);

        if (cliente != null) {
            // Ya existe, actualizamos su lista de comentarios
            coleccion.updateOne(eq("id_cliente", idCliente),
                    Updates.push("comentarios", nuevoComentario));
            //JOptionPane.showMessageDialog(null, "Comentario agregado correctamente.");
        } else {
            // No existe, creamos nuevo documento
            Document nuevoCliente = new Document("id_cliente", idCliente)
                    .append("comentarios", Arrays.asList(nuevoComentario));
            coleccion.insertOne(nuevoCliente);
            //JOptionPane.showMessageDialog(null, "Cliente nuevo creado con su primer comentario.");
        }
    }
    
    public static void insertarPreferencias(int idCliente,String idioma,String metodoPago,boolean notificaciones) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();

        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();
        Document nuevasPreferencias = new Document("idioma", idioma)
                .append("metodo_pago", metodoPago)
                .append("notificaciones", notificaciones);

        if (cliente != null) {
            if (cliente.containsKey("preferencias")) {
                JOptionPane.showMessageDialog(null, "Este cliente ya tiene preferencias registradas. No se pueden modificar.");
            } else {
                coleccion.updateOne(eq("id_cliente", idCliente),
                        Updates.set("preferencias", nuevasPreferencias));
                //JOptionPane.showMessageDialog(null, "Preferencias agregadas correctamente al cliente existente.");
            }
        } else {
            // Crear nuevo cliente con solo preferencias
            Document nuevoCliente = new Document("id_cliente", idCliente)
                    .append("preferencias", nuevasPreferencias);
            coleccion.insertOne(nuevoCliente);
            //JOptionPane.showMessageDialog(null, "Cliente nuevo creado con sus preferencias.");
        }
    }
    
    public static void modificarComentario(int idCliente,int indiceComentarioAModificar,String textoComentarioNuevo,Date nuevaFecha) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();

        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();
        if (cliente == null) {
            //JOptionPane.showMessageDialog(null, "El cliente con ID " + idCliente + " no existe.");
            return;
        }

        List<Document> comentarios = cliente.getList("comentarios", Document.class);

        if (comentarios == null || comentarios.isEmpty()) {
            //JOptionPane.showMessageDialog(null, "El cliente no tiene comentarios registrados.");
            return;
        }


        // Reemplazar el comentario en la lista
        Document nuevoComentario = new Document("texto", textoComentarioNuevo).append("fecha", nuevaFecha);
        comentarios.set(indiceComentarioAModificar, nuevoComentario);

        // Actualizar en la colección
        coleccion.updateOne(
            eq("id_cliente", idCliente),
            set("comentarios", comentarios)
        );

        //JOptionPane.showMessageDialog(null, "Comentario modificado exitosamente.");
    }
    
    //metodo para obtener comentarios de un cliente
    public static String[] obtenerComentariosDeunCliente(int id_cliente){
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();
        String[] opciones=null;

        Document cliente = coleccion.find(eq("id_cliente", id_cliente)).first();
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "El cliente con ID " + id_cliente + " no existe.");
            return opciones;
        }

        List<Document> comentarios = cliente.getList("comentarios", Document.class);

        if (comentarios == null || comentarios.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El cliente no tiene comentarios registrados.");
            return opciones;
        }

        // Mostrar los textos de los comentarios como opciones
        opciones = new String[comentarios.size()];
        for (int i = 0; i < comentarios.size(); i++) {
            opciones[i] = comentarios.get(i).getString("texto");
        }
        return opciones;
    }
    
    //metodo para obtener el indice del comentario de un cliente
    public static int obtenerIndiceComentarioCliente(int id_cliente,String ComentarioBuscado){
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();
        int indice=-1;

        Document cliente = coleccion.find(eq("id_cliente", id_cliente)).first();
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "El cliente con ID " + id_cliente + " no existe.");
            return indice;
        }

        List<Document> comentarios = cliente.getList("comentarios", Document.class);

        if (comentarios == null || comentarios.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El cliente no tiene comentarios registrados.");
            return indice;
        }
        
        for (int i = 0; i < comentarios.size(); i++) {
            if (comentarios.get(i).getString("texto").equals(ComentarioBuscado)) {
                indice = i;
                break;
            }
        }
        return indice;
    }
    
    
    //mostrar las preferencias a modificar de un cliente
    public static void mostrarPreferenciasAModificar(int idCliente,JTextField idioma,JComboBox<String> metodoPago,JCheckBox notificaciones){
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();
        Document doc = coleccion.find(eq("id_cliente", idCliente)).first();

        if (doc == null) {
            JOptionPane.showMessageDialog(null, "El cliente no existe.");
            return;
        }

        Document preferencias = doc.get("preferencias", Document.class);

        if (preferencias == null) {
            JOptionPane.showMessageDialog(null, "Este cliente no tiene preferencias registradas.");
            return;
        }
        
        idioma.setText(preferencias.getString("idioma"));
        
        //buscamos el valor del metodo_pago en el comboBox y lo seleccionamos
        for (int i = 0; i < metodoPago.getItemCount(); i++) {
            String item = metodoPago.getItemAt(i);
            if (item.equalsIgnoreCase(preferencias.getString("metodo_pago"))) {
                metodoPago.setSelectedIndex(i);
                return;
            }
        }
        
        if(preferencias.getBoolean("notificaciones")){
            notificaciones.setSelected(true);
        }else notificaciones.setSelected(false);

    }
    
    //metodo para modificar preferencias
    public static void modificarPreferencias(int idCliente, String idioma, String metodoPago, boolean notificaciones) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();

        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();

        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "El cliente con ID " + idCliente + " no existe.");
            return;
        }
        
        if(!cliente.containsKey("preferencias")){
            JOptionPane.showMessageDialog(null, "El cliente con ID " + idCliente + " aún no tiene preferencias registradas");
            return;
        }

        // Construir nuevo documento de preferencias
        Document nuevasPreferencias = new Document("idioma", idioma)
            .append("metodo_pago", metodoPago)
            .append("notificaciones", notificaciones);

        // Actualizar las preferencias en la base de datos
        coleccion.updateOne(
            eq("id_cliente", idCliente),
            set("preferencias", nuevasPreferencias)
        );

        //JOptionPane.showMessageDialog(null, "Preferencias actualizadas correctamente.");
    }
    
    //metodo para eliminar un comentario de un cliente
    public static void eliminarComentarioEspecifico(int idCliente, String comentarioBuscado ) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();
        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();

        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "El cliente con ID " + idCliente + " no existe.");
            return;
        }

        List<Document> comentarios = cliente.getList("comentarios", Document.class);

        if (comentarios == null || comentarios.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El cliente no tiene comentarios registrados.");
            return;
        }

        // Buscar el comentario seleccionado
        Document comentarioAEliminar = null;
        for (Document doc : comentarios) {
            if (doc.getString("texto").equals(comentarioBuscado)) {
                comentarioAEliminar = doc;
                break;
            }
        }

        if (comentarioAEliminar != null) {
            coleccion.updateOne(
                eq("id_cliente", idCliente),
                Updates.pull("comentarios", comentarioAEliminar)
            );
            //JOptionPane.showMessageDialog(null, "Comentario eliminado correctamente.");
        }
    }
    
    
    //metodo para eliminar las preferencias de un cliente
    public static void eliminarPreferencias(int idCliente) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();
        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();
        
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "El cliente con ID " + idCliente + " no existe.");
            return;
        }

        Document preferencias = cliente.get("preferencias", Document.class);

        if (preferencias == null || preferencias.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El cliente no tiene preferencias registradas.");
            return;
        }

        coleccion.updateOne(
            eq("id_cliente", idCliente),
            Updates.unset("preferencias")
        );
    }

    
    
    //metodo para eliminar un cliente de la coleccion
    public static void eliminarClientePorId(int idCliente) {
        //se establace la conexion y se guarda la coleccion de clientes_info
        conexion_MongoDB conexion = new conexion_MongoDB();
        MongoCollection<Document> coleccion = conexion.crearConexion();
        Document cliente = coleccion.find(eq("id_cliente", idCliente)).first();

        if (cliente == null) {
            return;
        }

        coleccion.deleteOne(eq("id_cliente", idCliente));
    }
}
