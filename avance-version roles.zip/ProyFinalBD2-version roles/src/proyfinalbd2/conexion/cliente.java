
package proyfinalbd2.conexion;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class cliente {
    private String nombre;
    private String email;
    private int telefono;
    private java.sql.Date fecha_registro;

    public cliente() {
    }

    public cliente(String nombre, String email, int telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }
    
    public cliente(String nombre, String email, int telefono, java.sql.Date fecha) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.fecha_registro = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public java.sql.Date getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(java.sql.Date fecha_registro) {
        this.fecha_registro = fecha_registro;
    }
    
    
    //mostrar cliente en una tabla
    public static void mostrarClientesEnTabla(JTable tablaClientes) {
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"id_cliente", "nombre", "email", "telefono", "fecha_registro"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);

        // Consulta SQL
        String sql = "SELECT * FROM clientes ORDER BY id_cliente ASC;";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[5];

        conexion c = new conexion(); 
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);

                modelo.addRow(datos);
            }

            // Asignar el modelo al JTable
            tablaClientes.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar clientes en la tabla: " + e.toString());
        }
    }
    
    //mostrar los clientes registrados y su id en JComboBox para que puedan ser seleccionados
    public static void mostrarClientesEnComboBox(JComboBox<String> comboBox){
        // Consulta SQL
        String sql = "select id_cliente,nombre from clientes order by id_cliente asc;";
        comboBox.removeAllItems();
        
        conexion c = new conexion(); 
        Statement st;
        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String id = rs.getString(1);
                String cliente = rs.getString(2);
                String opcion = id+"-"+cliente;
                comboBox.addItem(opcion);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los clientes en el comboBox: " + e.toString());
        }
    }
    
    //obtener el nombre de un cliente por su id
    public static String obtenerNombreCliente(int id_cliente){
        // Consulta SQL
        String sql = "select nombre from clientes where id_cliente="+id_cliente+";";

        String nombre = "";

        conexion c = new conexion(); 
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                nombre = rs.getString(1);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el nombre del cliente: " + e.toString());
        }
        return nombre;
    }
    
    //mostrar solo el id y el nombre del cliente en una tabla
    public static void mostrarIdYNombresEnTabla(JTable tablaClientes) {
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"ID", "Nombre"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);

        // Consulta SQL
        String sql = "select id_cliente,nombre from clientes order by id_cliente asc;";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[2];

        conexion c = new conexion(); 
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);

                modelo.addRow(datos);
            }

            // Asignar el modelo al JTable
            tablaClientes.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar clientes en la tabla: " + e.toString());
        }
    }
    
    //insertar cliente a la BD con la fecha actual por defecto
    public void insertarCliente(){
        conexion con=new conexion();
        String sql="insert into clientes(nombre,email,telefono) values(?,?,?);";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setString(1, this.nombre);
            cs.setString(2, this.email);
            cs.setInt(3, this.telefono);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "cliente registrado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //insertar cliente en la BD con una fecha específica
    public void insertarClienteConFecha(){
        conexion con=new conexion();
        String sql="insert into clientes(nombre,email,telefono,fecha_registro) values(?,?,?,?);";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setString(1, this.nombre);
            cs.setString(2, this.email);
            cs.setInt(3, this.telefono);
            cs.setDate(4, this.fecha_registro);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "cliente registrado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    
    //modificar cliente por id en la BD
    public void modificarCliente(int id){
        conexion con=new conexion();
        String sql="update clientes set nombre=?, email=?, telefono=?, fecha_registro=? where id_cliente=?;";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setString(1, this.nombre);
            cs.setString(2, this.email);
            cs.setInt(3, this.telefono);
            cs.setDate(4, this.fecha_registro);
            cs.setInt(5, id);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "cliente modificado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //mostrar datos del cliente seleccionado en la ventana modificar
    public void mostrarDatosClienteAModificar(String id,JTextField inputNombre,JTextField inputEmail,JTextField inputTelefono){
        conexion c=new conexion();
        String sql="";
        
        sql="select * from clientes where id_cliente="+id+";";
        
        String[] datos=new String[5];
        
        Statement st;
        
        try{
            st=c.establecerConexion().createStatement();
            
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                
                inputNombre.setText(datos[1]);
                inputEmail.setText(datos[2]);
                inputTelefono.setText(datos[3]);
                
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    
    //eliminar un cliente de la BD
    public void eliminarCliente(int id){
        conexion con=new conexion();
        String sql="delete from clientes where id_cliente=?;";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setInt(1, id);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "cliente eliminado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
}
