
package proyfinalbd2.conexion;

import java.sql.CallableStatement;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class pedidos {
    //insertar nuevo pedido en la bd postgresql
    public static void insertarPedido(int id_cliente, java.sql.Date fechaPedido, double total){
        conexion con=new conexion();
        String sql="insert into pedidos(id_cliente,fecha_pedido,total) values(?,?,?);";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setInt(1,id_cliente);
            cs.setDate(2,fechaPedido);
            cs.setDouble(3,total);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "Pedido registrado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //actualizar el total de un pedido
    public static void actualizarTotal(int id_pedido){
        conexion con=new conexion();
        //codigo sql para obtener el subtotal de los detalles_pedido del pedido que se quiere actualizar
        String sqlSubtotal="select subtotal from detalle_pedido where id_pedido="+id_pedido+";";
        
        //codigo sql para actualizar el total del pedido
        String sqlTotal="update pedidos set total=? where id_pedido=?;";
        
        double total=0;
        try{
            Statement st=con.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sqlSubtotal);

            while (rs.next()) {
                //el total sera igual a la suma de todos los subtotales de ese pedido
                total+=rs.getDouble(1);
            }
            
            //se actualiza el total del pedido
            CallableStatement cs=con.establecerConexion().prepareCall(sqlTotal);
            cs.setDouble(1, total); 
            cs.setInt(2, id_pedido);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "total del pedido actualizado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //modificar pedido en la bd
    public static void modificarPedido(int id_pedido,int nuevoIdCliente,String nuevaFecha){
        conexion con=new conexion();
        String sql="update pedidos set id_cliente=?, fecha_pedido=? where id_pedido=?;";
        
        try{
            // Parsear el String de la fecha nueva a java.util.Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date fechaUtil = sdf.parse(nuevaFecha);

            // Convertir la fecha a java.sql.Date para poder ingresarla a la bd de postgresql
            java.sql.Date fechaSQL = new java.sql.Date(fechaUtil.getTime());
            
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setInt(1, nuevoIdCliente); 
            cs.setDate(2, fechaSQL);
            cs.setInt(3, id_pedido);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "Pedido modificado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //eliminar un pedido de la BD
    public static void eliminarPedido(int id_pedido){
        conexion con=new conexion();
        String sql="delete from pedidos where id_pedido=?;";
        
        try{
            //primero eliminamos los detalles del pedido de la bd
            eliminarDetallesPedido(id_pedido);
            
            //ahora eliminamos el pedido de la bd
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setInt(1, id_pedido);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "pedido eliminado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //eliminar los detalle de un pedido
    public static void eliminarDetallesPedido(int id_pedido){
        conexion con=new conexion();
        String sql="delete from detalle_pedido where id_pedido=?;";
        
        try{
            CallableStatement cs=con.establecerConexion().prepareCall(sql);
            cs.setInt(1, id_pedido);
            cs.execute();
            
            //JOptionPane.showMessageDialog(null, "detalles del pedido eliminado con exito");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error: "+e.toString());
        }
    }
    
    //obtener el id_pedido del último pedido registrado
    public static int obtenerUltimoIdPedidoRegistrado(){
        String sql = "select id_pedido from pedidos order by id_pedido desc limit 1;";
        int id_pedido=0;
        
        conexion c = new conexion();
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                id_pedido=rs.getInt(1);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al conectarse con la BD: " + e.toString());
        }
        return id_pedido;
    }
    
    //mostrar datos de los pedidos en una tabla
    public static void MostrarPedidosEnTabla(JTable tablaPedidos){
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"ID Pedido", "ID Cliente", "Cliente", "Fecha", "Total"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);

        // Consulta SQL
        String sql = "select p.id_pedido,p.id_cliente, c.nombre,p.fecha_pedido,p.total from pedidos as p inner join clientes as c on p.id_cliente=c.id_cliente;";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[5];

        conexion c = new conexion(); // tu clase de conexión
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);

                modelo.addRow(datos);
            }

            // Asignar el modelo al JTable
            tablaPedidos.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar pedidos en la tabla: " + e.toString());
        }
    }
    
    //mostrar pedidos y sus detalles en una tabla
    public static void MostrarPedidosYDetallesEnTabla(JTable tablaPedidos){
        // Crear un nuevo modelo de tabla con los encabezados
        String[] titulos = {"ID Pedido", "Cliente", "Fecha", "Producto", "Cantidad", "Subtotal", "Total"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);

        // Consulta SQL
        String sql = "select d.id_pedido,c.nombre,p.fecha_pedido,prod.nombre,d.cantidad,d.subtotal,p.total from detalle_pedido as d inner join productos as prod on d.id_producto=prod.id_producto inner join pedidos as p on d.id_pedido=p.id_pedido inner join clientes as c on p.id_cliente=c.id_cliente order by id_detalle asc;";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[7];

        conexion c = new conexion(); // tu clase de conexión
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                datos[6] = rs.getString(7);

                modelo.addRow(datos);
            }

            // Asignar el modelo al JTable
            tablaPedidos.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar pedidos y detalles en la tabla: " + e.toString());
        }
    }
    
    //mostrar los datos de los pedidos
    public static void mostrarPedidos(){
        String sql = "select * from pedidos order by id_pedido asc;";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[4];

        conexion c = new conexion();
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                
                System.out.println("id del pedido: "+datos[0]+"-id del cliente: "+datos[1]+"-fecha del pedido: "+datos[2]+"-total del pedido: "+datos[3]);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos: " + e.toString());
        }
    }
    
    //mostrar los datos del pedido con el nombre del cliente
    public static void mostrarPedidosConNombreCliente(){
        String sql = "select p.id_pedido,c.nombre,p.fecha_pedido,p.total from pedidos as p inner join clientes as c on p.id_cliente=c.id_cliente;";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[4];

        conexion c = new conexion();
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                
                System.out.println("id del pedido: "+datos[0]+"-nombre del cliente: "+datos[1]+"-fecha del pedido: "+datos[2]+"-total del pedido: "+datos[3]);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos: " + e.toString());
        }
    }
    
    //mostrar pedidos de un cliente en específico
    public static void mostrarPedidosDeUnCliente(int id_cliente){
        String sql = "select p.id_pedido,c.nombre,p.fecha_pedido,p.total from pedidos as p inner join clientes as c on p.id_cliente=c.id_cliente where p.id_cliente="+id_cliente+";";

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[4];

        conexion c = new conexion();
        Statement st;

        try {
            st = c.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                
                System.out.println("id del pedido: "+datos[0]+"-nombre del cliente: "+datos[1]+"-fecha del pedido: "+datos[2]+"-total del pedido: "+datos[3]);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos: " + e.toString());
        }
    }
}
