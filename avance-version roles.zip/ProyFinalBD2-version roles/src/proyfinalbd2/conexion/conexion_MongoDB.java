
package proyfinalbd2.conexion;

import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import org.bson.Document;

public class conexion_MongoDB {
    private static final String URI = "mongodb://localhost:27017";
    private static final String DB_NAME = "dbInformacionClientes";
    private static final String COLLECTION_NAME = "clientes_info";
    
    //metodo para conectarse a mongodb y devolver la colección de clientes
    public MongoCollection<Document> crearConexion(){
        MongoClient mongoClient;
        MongoDatabase database;
        MongoCollection<Document> coleccion = null;
        
        try{
            mongoClient = MongoClients.create(URI);
            database = mongoClient.getDatabase(DB_NAME);
            coleccion = database.getCollection(COLLECTION_NAME);
            
        }catch(MongoException e){
            JOptionPane.showMessageDialog(null, "Error en la conexion a mongodb: "+e.toString());
        }
        return coleccion;
    }
}
